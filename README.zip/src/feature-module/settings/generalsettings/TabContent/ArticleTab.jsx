import React from 'react'

const ArticleTab = () => {
  return (
    <div>ArticleTab</div>
  )
}

export default ArticleTab