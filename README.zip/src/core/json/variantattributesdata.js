export const variantattributesdata = [
	{
		"id":1,
		"variant": "Size (T-shirts)",
		"values": "S,M,L,XL",
		"createdon": "25 May 2023",
		"status": "Active",
		
	},
	{
		"id":2,
		"variant": "Size (Shoes)",
		"values": "5,6,7,8,9",
		"createdon": "24 Jun 2023",
		"status": "Active",
		
	},
	{
		"id":3,
		"variant": "Color",
		"values": "Red, Blue, Green",
		"createdon": "23 Jul 2023",
		"status": "Active",
		
	},
	{
        "id":4,
		"variant": "Memory",
		"values": "64 GB, 128 GB, 512 GB",
		"createdon": "22 Aug 2023",
		"status": "Active",
		
	},
	{
		"id":5,
		"variant": "Storage",
		"values": "250GB, 1TB",
		"createdon": "21 Sep 2023",
		"status": "Active",
		
	}
]