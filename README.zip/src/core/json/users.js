export const userlisadata = [
	{
		"id":1,
        "img":"assets/img/users/user-15.jpg",
		"username": "Thomas",
		"phone": "+12163547758",
		"email": "thomas@example.com",
		"role": "Admin",
		"createdon": "19 Jan 2023",
		"status": "Inactive",
		
	},
	{
		"id":2,
        "img":"assets/img/users/user-16.jpg",
		"username": "Rose",
		"phone": "+11367529510",
		"email": "rose@example.com",
		"role": "Manager",
		"createdon": "23 Jan 2023",
		"status": "Active",
		
	},
	{
		"id":3,
        "img":"assets/img/users/user-17.jpg",

		"username": "Benjamin",
		"phone": "+15362789414",
		"email": "benjamin@example.com",
		"role": "Salesman",
		"createdon": "07 Feb 2023",
		"status": "Active",
		
	},
	{
		"id":4,
        "img":"assets/img/users/user-18.jpg",

		"username": "Kaitlin",
		"phone": "+18513094627",
		"email": "kaitlin@example.com",
		"role": "Supervisor",
		"createdon": "18 Feb 2023",
		"status": "Active",
		
	},
	{
		"id":5,
        "img":"assets/img/users/user-19.jpg",

		"username": "Lilly",
		"phone": "+14678219025",
		"email": "lilly@example.com",
		"role": "Store Keeper",
		"createdon": "16 Mar 2023",
		"status": "Inactive",
		
	},
	{
		"id":6,
        "img":"assets/img/users/user-20.jpg",

		"username": "Freda",
		"phone": "+10913278319",
		"email": "freda@example.com",
		"role": "Purchase",
		"createdon": "29 Mar 2023",
		"status": "Inactive",
		
	},
	{
		"id":7,
        "img":"assets/img/users/user-21.jpg",

		"username": "Alwin",
		"phone": "+19125852947",
		"email": "alwin@example.com",
		"role": "Delivery Biker",
		"createdon": "03 Apr 2023",
		"status": "Active",
		
	},
	{
		"id":8,
        "img":"assets/img/users/user-22.jpg",

		"username": "Maybelle",
		"phone": "+13671835209",
		"email": "maybelle@example.com",
		"role": "Maintenance",
		"createdon": "13 Apr 2023",
		"status": "Active",
		
	},
	{
		"id":9,
        "img":"assets/img/users/user-23.jpg",

		"username": "Ellen",
		"phone": "+19756194733",
		"email": "ellen@example.com",
		"role": "Quality Analyst",
		"createdon": "17 May 2023",
		"status": "Active",
		
	},
	{
		"id":10,
        "img":"assets/img/users/user-24.jpg",

		"username": "Grace",
		"phone": "+19167850925",
		"email": "grace@example.com",
		"role": "Accountant",
		"createdon": "21 May 2023",
		"status": "Active",
		
	}
]